package com.example.exercicio6

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun sortear(view: View) {
        val numero = Random.nextInt(0, 11)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)

        txtResultado.text = "Número sorteado: $numero"

        if (numero % 2 == 0) {
            txtResultado.setTextColor(Color.parseColor("#1F7A6C"))
            println("número par sorteado: $numero — cor aplicada: #1F7A6C")
        } else {
            txtResultado.setTextColor(Color.parseColor("#C62828"))
            println("número ímpar sorteado: $numero — cor aplicada: #C62828")
        }
    }
}
