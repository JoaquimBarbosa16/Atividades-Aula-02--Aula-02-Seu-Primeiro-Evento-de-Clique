# Aula 02 — Clique e Sortear

Projetos da lista de exercícios da Disciplina de Mobile — Aula 02.

## Exercícios

- **exercicio1** — Saudar: clique + Logcat + atualização do TextView.
- **exercicio2** — Contador: contador persistente entre cliques.
- **exercicio3** — Sorteio: identifica número par ou ímpar no Logcat.
- **exercicio4** — Dado: sorteia de 1 a 6 e mantém histórico de rolagens.
- **exercicio5** — Aviso, Sortear e Ambos: três funções e três botões.
- **exercicio6** — Sorteio com cor: muda a cor conforme a paridade e registra no Logcat.

## Como abrir

Cada exercício é um projeto Android independente.

Abra a pasta do exercício desejado no Android Studio, por exemplo:

`exercicio1`

Depois aguarde a sincronização do Gradle e execute no emulador.

## Entrega

O repositório pode seguir esta mesma organização. Faça um commit descritivo para cada exercício, por exemplo:

- `feat: adiciona exercicio 1`
- `feat: adiciona exercicio 2`
- `feat: adiciona exercicio 3`
- `feat: adiciona exercicio 4`
- `feat: adiciona exercicio 5`
- `feat: adiciona exercicio 6`
