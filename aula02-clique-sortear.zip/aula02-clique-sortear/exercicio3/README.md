# Exercício 3 — Sorteio com aviso no Logcat

Projeto da disciplina de Mobile — Aula 02.

## Como executar

1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Execute no emulador ou dispositivo Android.
4. Para conferir as mensagens, abra o **Logcat** no Android Studio.

## Conteúdo

Sorteio com aviso no Logcat

Este projeto utiliza Kotlin e `android:onClick`, conforme solicitado na atividade.
