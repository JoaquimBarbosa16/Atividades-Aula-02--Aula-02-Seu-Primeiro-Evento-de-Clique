package com.example.exercicio3

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun sortear(view: View) {
        val numero = Random.nextInt(0, 11)

        val txtResultado = findViewById<TextView>(R.id.txtResultado)
        txtResultado.text = "Número sorteado: $numero"

        if (numero % 2 == 0) {
            println("número par sorteado: $numero")
        } else {
            println("número ímpar sorteado: $numero")
        }
    }
}
