package com.example.exercicio4

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private var quantidadeRolagens = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun rolarDado(view: View) {
        quantidadeRolagens++

        val resultado = Random.nextInt(6) + 1

        val txtResultado = findViewById<TextView>(R.id.txtResultado)
        txtResultado.text = "Rolagem $quantidadeRolagens: resultado $resultado"

        println("Rolagem $quantidadeRolagens: resultado $resultado")
    }
}
