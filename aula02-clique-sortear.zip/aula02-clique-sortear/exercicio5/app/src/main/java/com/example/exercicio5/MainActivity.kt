package com.example.exercicio5

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun aviso(view: View) {
        println("Aviso: botão Aviso foi clicado")
    }

    fun sortear(view: View) {
        val numero = Random.nextInt(0, 11)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)
        txtResultado.text = "Número sorteado: $numero"
    }

    fun avisarESortear(view: View) {
        println("Aviso: botão Ambos foi clicado")

        val numero = Random.nextInt(0, 11)
        val txtResultado = findViewById<TextView>(R.id.txtResultado)
        txtResultado.text = "Número sorteado: $numero"

        println("Sorteio realizado pelo botão Ambos: $numero")
    }
}
